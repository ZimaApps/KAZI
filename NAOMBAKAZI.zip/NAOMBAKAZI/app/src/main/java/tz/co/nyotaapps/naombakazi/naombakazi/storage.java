package tz.co.nyotaapps.naombakazi.naombakazi;

import org.json.JSONArray;

public class storage {
    public static String kikobaId = "";
    public static String kiingilio = "";
    public static String ada = "";
    public static String hisa = "";
    public static String faini = "";
    public static String chini = "";
    public static boolean state = false;
    public static String mikopo = "";

    public static String userName = "";
    public static String userNumber = "";
    public static String userId = "";
    public static String riba = "";
    public static String tenure = "";
    public static String fainiyamikopo = "";
    public static JSONArray groupdata;
    public static JSONArray userVicoba;
    public static String kikobaname = "";
    public static String creatorid = "";
    public static String creatorname = "";
    public static String creatorphone = "";







}
