package tz.co.nyotaapps.naombakazi.naombakazi;

public class Config {
    // File upload url (replace the ip with your server address)
    public static final String FILE_UPLOAD_URL = "http://naombakazi.nyotaapps.co.tz/register.php";
    public static final String FILE_UPDATE_URL = "http://naombakazi.nyotaapps.co.tz/updateinfo.php";
    public static final String FILE_UPLOAD_URL_MESEJI = "http://naombakazi.nyotaapps.co.tz/sendmeseji.php";
    // Directory name to store captured images and videos
    public static final String IMAGE_DIRECTORY_NAME = "Android File Upload";
}
