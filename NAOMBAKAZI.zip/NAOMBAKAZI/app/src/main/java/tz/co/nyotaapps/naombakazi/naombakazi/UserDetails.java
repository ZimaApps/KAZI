package tz.co.nyotaapps.naombakazi.naombakazi;

public class UserDetails {
    static String usernamex = "";
    static String username = "";
    static String password = "";
    static String chatWith = "";
    static String joint = "";


}
